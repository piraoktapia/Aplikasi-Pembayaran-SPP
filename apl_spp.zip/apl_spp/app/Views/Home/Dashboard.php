<?=$this->include('Home/Header');?>

<!-- Awal Konten Aplikasi -->
<main role="main" class="flex-shrink-0 bg-success" style="background-image: url('/backg_1.jpeg'); height: 125vh; width: 100%; background-repeat : no-repeat;">
">
  <div class="container">

    <?php 
    if(empty($intro)){
        $this->renderSection('content');
    } else {
        echo $intro;
    }
    ?>
  </div>
</main>

<?=$this->include('Home/Footer');?>